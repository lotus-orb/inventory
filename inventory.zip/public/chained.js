jQuery( document ).ready(function( $ ) {
    $("#barang").chained("#category");
}); 