@extends('layouts.admin')

@section('content')
<div class="content">
	<div class="page-inner">
		<div class="page-header">
			<ul class="breadcrumbs" style="margin: 0 !important; padding: 0px !important;">
				<li class="nav-home">
					<a href="#">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Tables</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Datatables</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<div class="card-title">SPK Detail ({{$spks->no_spk}})</div>
					</div>
					<div class="card-body">
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Nomor SPK</label>
									<pre>{{$spks->no_spk}}</pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Tahun Anggaran</label>
									<pre>{{$spks->tahun_anggaran}}</pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Nama Vendor</label>
									@foreach($vendors as $vendor)
										@if($spks->vendor_id == $vendor->id)
										<pre>{{$vendor->nm_vendor}}</pre>
										@endif	
									@endforeach
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Nama PIC</label>
									<pre>{{$spks->nm_pic}}</pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Keterangan</label>
									<pre>{{$spks->keterangan}}</pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Jumlah Barang</label>
									<pre></pre>	
								</div>
							</div>
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<a href="{{route('spks.index')}}" class="btn btn-info m-r-10"><i class="fa fa-angle-left m-r-10"></i> Batal</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection