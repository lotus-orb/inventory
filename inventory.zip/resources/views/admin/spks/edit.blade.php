@extends('layouts.admin')

@section('styles')
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
@endsection

@section('content')
<div class="content">
	<div class="page-inner">
		<div class="page-header">
			<ul class="breadcrumbs" style="margin: 0 !important; padding: 0px !important;">
				<li class="nav-home">
					<a href="#">
						<i class="flaticon-home"></i>
						Dashboard
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Tables</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Datatables</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<div class="d-flex align-items-center">
							<h4 class="card-title">Edit SPK {{ $spks->no_spk }}</h4>
						</div>
					</div>
					<div class="card-body">
						<form action="{{route('spks.update', $spks->id)}}" method="POST">
							{{method_field('PUT')}}
							{{csrf_field()}}
							<div class="form-group" >
								<label for="nm_kategori">Nomor SPK</label>
								<input type="text" class="form-control" name="no_spk" value="{{ $spks->no_spk }}" required>
							</div>
							<div class="form-group" >
								<label for="tahun_anggaran">Tahun Anggaran</label>
								<input type="text" class="form-control" name="tahun_anggaran" value="{{ $spks->tahun_anggaran }}"required>
							</div>
							<div class="form-group" >
								<label for="vendor_id">Nama Perusahaan</label>
								<select name="vendor_id" class="form-control">
									@foreach ($vendors as $vendor)
										@if($spks->vendor_id == $vendor->id)
											<option value="{{$vendor->id}}">{{ $vendor->nm_vendor }} </option>
										@endif
									@endforeach
									<option value="">Pilih Nama Vendor</option>
									@foreach ($vendors as $vendor)
									<option value="{{ $vendor->id }}">{{ $vendor->nm_vendor }}</option>
									@endforeach
								</select>
							</div>
							<div class="form-group" >
								<label for="nm_pic">Nama PIC</label>
								<input type="text" class="form-control" name="nm_pic" value="{{ $spks->nm_pic }}" required>
							</div>
							<div class="form-group" >
								<label for="ketarangan">Keterangan (Optional)</label>
								<textarea class="form-control" name="keterangan">{{ $spks->keterangan }}</textarea>
							</div>
							<a href="{{route('spks.index')}}" class="btn btn-danger m-r-10"><i class="fa fa-angle-left m-r-10"></i> Batal</a>
							<button class="btn btn-primary" type="submit">Simpan</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@include('admin.incomings.script')