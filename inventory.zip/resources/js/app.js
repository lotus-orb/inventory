require('./bootstrap');

window.Vue = require('vue');

import Buefy from 'buefy';

// ES6 Modules or TypeScript
import Swal from 'sweetalert2';

Vue.use(Buefy);


//Vue.component('example-component', require('./components/ExampleComponent.vue'));
