<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="page-inner">
		<div class="page-header">
			<ul class="breadcrumbs" style="margin: 0 !important; padding: 0px !important;">
				<li class="nav-home">
					<a href="#">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Tables</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Datatables</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<?php $__currentLoopData = $spks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($spk->id == $incomings->spk_id): ?>
								<div class="card-title">Barang Masuk Detail untuk Nomor SPK (<?php echo e($spk->no_spk); ?>)</div>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="card-body">
						<div class="row">
							<?php $__currentLoopData = $spks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($spk->id == $incomings->spk_id): ?>
									<div class="col-sm-12">
										<div class="form-group">
											<label for="name">Nomor SPK</label>
											<pre><?php echo e($spk->no_spk); ?></pre>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label for="name">Tahun Anggaran</label>
											<pre><?php echo e($spk->tahun_anggaran); ?></pre>
										</div>
									</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Tanggal Masuk Barang</label>
									<pre><?php echo e($incomings->tgl_masuk); ?></pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<div class="table-responsive">
										<table class="table table-bordered table-head-bg-primary table-bordered-bd-primary">
											<thead>
												<tr>
													<th>Kode Barang</th>
													<th>Kategori Barang</th>
													<th>Nama Barang Masuk</th>
													<th><i>Serial Number</i></th>
													<th>Barcode</th>
													<th>Foto Barang</th>
												</tr>
											</thead>
											<tbody>
												<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <tr>
							                    	<td style="text-align: center;">KDBR0000<?php echo e($item->id); ?></td>
						                        	<td><?php echo e($item->category->nm_kategori); ?></td>
							                        <td><?php echo e($item->nm_barang); ?></td>
							                        <td><?php echo e($item->pivot->no_seri); ?></td>
							                        <td>
							                        	<img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->backgroundColor(254,168,56,1)->merge('\qr_bg.png', .3)->size(100)->errorCorrection('H')->generate('KDBR0000'.$item->id.' '.$item->category->nm_kategori.' '.$item->nm_barang));; ?> ">
							                        	</td>
							                        <td>
							                        	<figure class="has-text-centered">
										                  <a href="#" data-toggle="modal" data-target="#addRowModal<?php echo e($item->id); ?>">
										                    <img src="<?php echo e(Storage::url('public/upload/'.$item->photo)); ?>" class="m-t-10" alt="photo" width="100">
										                  </a>
										                </figure>
										                <div class="modal fade" id="addRowModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
															<div class="modal-dialog" role="document">
																<div class="modal-header no-bd">
																	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																		<span aria-hidden="true" style="color: #fff;">&times;</span>
																	</button>
																</div>
																<div class="modal-content">
										                    		<img src="<?php echo e(Storage::url('public/upload/'.$item->photo)); ?>" alt="photo" width="100%">
										                    	</div>
										                    </div>
										                </div>
							                        </td>
							                    </tr>
							                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                    </tbody>
						                </table>
						            </div>
				            	</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Nomor Referensi Barang (No. Surat Jalan/Terima Barang)</label>
									<pre><?php echo e($incomings->no_ref); ?></pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Nama PIC</label>
									<pre><?php echo e($incomings->nm_pic); ?></pre>	
								</div>
							</div>
							<div class="col-sm-12">
								<div class="form-group">
									<label for="name">Keterangan (Optional)</label>
									<pre><?php echo e($incomings->keterangan); ?></pre>	
								</div>
							</div>
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-md-12">
								<a href="<?php echo e(route('incomings.index')); ?>" class="btn btn-info m-r-10"><i class="fa fa-angle-left m-r-10"></i> Back</a>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\inventory\resources\views/admin/incomings/show.blade.php ENDPATH**/ ?>