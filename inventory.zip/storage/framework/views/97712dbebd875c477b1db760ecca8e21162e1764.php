<?php $__env->startSection('content'); ?>
	<div class="container container-login animated fadeIn" style="padding: 30px 25px !important;">
		<img src="<?php echo e(asset('lotus_logo.png')); ?>" class="m-b-30 m-l-60" width="200">
		<div class="login-form">
			<form method="POST" action="<?php echo e(route('login')); ?>">
        	<?php echo csrf_field(); ?>
				<div class="form-group form-floating-label">
					<input id="email" name="email" type="email" type="text" class="form-control input-border-bottom <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="off" autofocus>
					<label for="username" class="placeholder">Username</label>
					<?php if($errors->has('email')): ?>
                        <small id="email" class="form-text text-muted">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </small>
                    <?php endif; ?>
				</div>
					

				<div class="form-group form-floating-label">
					<input id="password" name="password" type="password" class="form-control input-border-bottom <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="current-password">
					<label for="password" class="placeholder">Password</label>
					<div class="show-password">
						<i class="icon-eye"></i>
					</div>
					<?php if($errors->has('password')): ?>
                        <small id="password" class="form-text text-muted">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </small>
                    <?php endif; ?>
				</div>
					

				<div class="form-action mb-3">
					<button type="submit" class="btn btn-primary btn-rounded btn-login">Sign In</button>
				</div>

				<div class="login-account">
					<span class="msg">Don't have an account yet ?</span>
					<a href="<?php echo e(route('register')); ?>" id="show-signup" class="link">Sign Up</a>
				</div>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\inventory\resources\views/auth/login.blade.php ENDPATH**/ ?>