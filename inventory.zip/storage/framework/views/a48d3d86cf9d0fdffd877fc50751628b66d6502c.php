<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title><?php echo e(config('app.name')); ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="<?php echo e(asset('assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo e(asset('assets/css/fonts.min.css')); ?>']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>


	<!-- CSS Files -->
	<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/atlantis.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>">
	<?php echo $__env->yieldContent('styles'); ?>
	
</head>
<body>
	<div class="wrapper" id="app">
		<?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->make('admin.includes.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="main-panel">
			<?php echo $__env->yieldContent('content'); ?>
			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<div class="copyright ml-auto">
							Copyright &copy; 2019 <?php echo e(config('app.name')); ?> , All Rights Reserved
						</div>
					</nav>			
				</div>
			</footer>
		</div>
	</div>
	
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('admin.includes.script_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH D:\Project\inventory\resources\views/layouts/admin.blade.php ENDPATH**/ ?>