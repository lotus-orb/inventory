<?php $__env->startSection('scripts'); ?>
  	<script src="<?php echo e(asset('assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
	<script type="text/javascript">
	    $(document).ready(function() {

	      var t = $('#datatable').DataTable({
	      	  "drawCallback": function( settings ) {
	      	 	$('body').on('click', '.hapus', function( e ) {
		            e.preventDefault();
		            var me = $(this),
		            	url = me.attr('href'),
		            	title = me.attr('title');

		            Swal.fire({
					  title: 'Anda yakin akan menghapus ' + title + ' ?',
					  text: 'Kami tidak bertanggung jawab atas tindakan ini!',
					  type: 'warning',
					  showCancelButton: true,
					  confirmButtonColor: '#3085d6',
					  cancelButtonColor: '#d33',
					  confirmButtonText: 'Yes, hapus data!'
					}).then((result) => {
				        if (result.value) {
				            $.ajax({
				                url: url,
					            type: 'DELETE',
					            data: {method: '_DELETE'},
					            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
				                success: function (response) {
				                    $('#datatable').DataTable().ajax.reload();
				                    Swal.fire({
				                        type: 'success',
				                        title: 'Success!',
				                        text: 'Data berhasil dihapus!'
				                    });
				                },
				                error: function (xhr) {
				                    Swal.fire({
				                        type: 'error',
				                        title: 'Oops...',
				                        text: 'Terjadi Kesalahan!'
				                    });
				                }
				            });
				        }
				    });
		        });
		        $('body').on('click', '.photos', function( e ) {
	      	 		$('#myModal').modal('show');  
		        });
			  },
	          processing: true,
	          serverSide: true,
	          "aaSorting": [[ 0,"desc" ]] ,
	          "searchable": false,
	          "orderable": false,
	          "targets": 0,
	          ajax: '<?php echo e(route('data_spk')); ?>',
	          columns: [
	              {data: 'DT_RowIndex', name: 'DT_RowIndex'},
	              {data: 'no_spk', name: 'no_spk'},
	              {data: 'tahun_anggaran', name: 'tahun_anggaran'},
	              {data: 'nm_vendor', name: 'nm_vendor'},
	              {data: 'jml', name: 'jml'},
	              {data: 'stats', name: 'stats'},
	              {data: 'action', name: 'action', orderable: false, searchable: false, "width" : "20%"}
	          ]
	        });
	      });
	</script>
 <?php $__env->stopSection(); ?><?php /**PATH D:\Project\inventory\resources\views/admin/spks/script.blade.php ENDPATH**/ ?>