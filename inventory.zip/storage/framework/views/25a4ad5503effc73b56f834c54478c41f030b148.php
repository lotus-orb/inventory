<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="page-inner">
		<div class="page-header">
			<ul class="breadcrumbs" style="margin: 0 !important; padding: 0px !important;">
				<li class="nav-home">
					<a href="#">
						<i class="flaticon-home"></i>
						Dashboard
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Tables</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a href="#">Datatables</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<div class="d-flex align-items-center">
							<h4 class="card-title">Tambah Barang Masuk</h4>
						</div>
					</div>
					<div class="card-body">
						<form action="<?php echo e(route('incomings.update', $incomings->id)); ?>" method="POST" id="add_item">
						  <?php echo e(method_field('PUT')); ?>

				          <?php echo e(csrf_field()); ?>

				          	<div class="form-group">
								<label for="no_spk">Nomor SPK</label>
								<select id="spk" name="spk_id" class="form-control" required>
									<?php $__currentLoopData = $spks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(!empty($incomings->spk_id) and $incomings->spk_id == $spk->id): ?>
											<option value="<?php echo e($incomings->spk_id); ?>"><?php echo e($spk->no_spk); ?> </option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<option value="">Pilih Nomor SPK</option>
									<?php $__currentLoopData = $spks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($spk->id); ?>"><?php echo e($spk->no_spk); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>

							<div class="form-group">
								<label for="tahun_anggaran">Tahun Anggaran</label>
								<select id="thn" name="tahun_anggaran" class="form-control" readonly disabled>
								  	<?php $__currentLoopData = $spks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($spk->tahun_anggaran); ?>" class="<?php echo e($spk->id); ?>"><?php echo e($spk->tahun_anggaran); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </select>
							</div>
							
							<div class="form-group">
								<label for="tgl_masuk">Tanggal Masuk Barang</label>
								<input class="form-control" name="tgl_masuk" id="datepicker" autocomplete="off" value="<?php echo e($incomings->tgl_masuk); ?>" required>
							</div>

							<div class="form-group">
								<div class="table-responsive">
									<table class="table no-border">
				                        <td style="padding: 0 !important; border-color: #ffffff !important;border-right: 20px solid;">
				                        	<label for="barang">Kategori Barang</label>
								          	<select id="category" class="form-control" style="height: calc(2.25rem + 2px) !important;">
							                  <option value="">Pilih Kategori</option>
							                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->nm_kategori); ?> </option>
							                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							                </select>
				                        </td>
				                        <td style="padding: 0 !important; border-color: #ffffff !important;border-right: 20px solid;">
				                        	<label for="barang">Nama Barang Masuk</label>
								          	<select id="item" class="form-control" style="height: calc(2.25rem + 2px) !important;">
							                  <option value="">Pilih Nama barang</option>
							                  <?php $__currentLoopData = $itemall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <option value="<?php echo e($itemss->id); ?>" class="<?php echo e($itemss->category_id); ?>"><?php echo e($itemss->nm_barang); ?> </option>
							                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							                </select>
				                        </td>
				                        <td style="padding: 0 !important; border-color: #ffffff !important;border-right: 20px solid;">
				                        	<label for="barang"><i>Serial Number</i></label>
				                        	<input class="form-control" id="no_seri" style="height: calc(2.25rem + 2px) !important;">
								          	
				                        </td>
				                        <td style="padding: 0 !important; border-color: #ffffff !important;border-right: 20px solid;">
				                        	<label for="barang">Barcode</label>
								          	<input class="form-control" id="barcode" style="height: calc(2.25rem + 2px) !important;">
				                        </td>
				                        <td>
				                        	<button type="button" id="add" class="btn btn-primary btn-sm m-t-15">
												<i class="fa fa-plus"></i>
											</button>
				                        </td> 
					                </table>
					            </div>
			            	</div>

			            	<div class="form-group">
			            		<table class="table table-bordered table-head-bg-info table-bordered-bd-info mt-4">
			            			<thead>
			            				<tr>
				            				<th>Kategori Barang</th>
				            				<th>Nama Barang Masuk</th>
				            				<th>Serial Number</th>
				            				<th>Barcode</th>
				            				<th></th>
			            				</tr>
			            			</thead>
			            			<tbody id="tab">
			            				<?php 
			            					$i = 1;
			            					$c = 1;
			            				?>
			            				<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                    <tr id="row<?php echo e($i++); ?>" class="tab_added">
					                        	<td>
					                        		<input type="hidden" name= "category_id[]" value="<?php echo e($item->category->id); ?>">
					                        		<?php echo e($item->category->nm_kategori); ?>

					                        	</td>
						                        <td>
						                        	<input type="hidden" name= "items[]" value="<?php echo e($item->id); ?>">
						                        	<?php echo e($item->nm_barang); ?>

						                        </td>
						                        <td>
						                        	<input type="hidden" name= "no_seri[]" value="<?php echo e($item->pivot->no_seri); ?>">
						                        	<?php echo e($item->pivot->no_seri); ?>

						                        </td>
						                        <td>
						                        	<input type="hidden" name= "barcode[]" value="<?php echo e($item->pivot->barcode); ?>">
						                        	<?php echo e($item->pivot->barcode); ?>

						                        </td>
						                        <td>
										           	<button type="button" name="remove" id="<?php echo e($c++); ?>" class="btn btn-danger btn-sm btn_remove">
										           		<i class="fa fa-times"></i>
										           	</button>
									           	</td>
						                    </tr>
					                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            			</tbody>
			            		</table>
			            	</div>

			            	<div class="form-group">
								<label for="pic">Nomor Referensi Barang (No. Surat Jalan/Terima Barang)</label>
								<input class="form-control" name="no_ref" value="<?php echo e($incomings->no_ref); ?>" required>
							</div>

			            	<div class="form-group">
								<label for="pic">Nama PIC</label>
								<input class="form-control" name="nm_pic" value="<?php echo e($incomings->nm_pic); ?>" required>
							</div>

							<div class="form-group">
								<label for="pic">Keterangan</label>
								<textarea class="form-control" name="keterangan"> <?php echo e($incomings->keterangan); ?></textarea>
							</div>

							<a href="<?php echo e(route('incomings.index')); ?>" class="btn btn-danger m-r-10"><i class="fa fa-angle-left m-r-10"></i> Batal</a>
					        <button class="btn btn-primary" type="submit" id="submit">Simpan</button>
				        </form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.incomings.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\inventory\resources\views/admin/incomings/edit.blade.php ENDPATH**/ ?>